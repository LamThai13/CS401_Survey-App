# CS401_Survey-App
Rating and Voting System
Setup
The first thing to do is to clone the repository:

$ git clone https://github.com/LamThai13/CS401_Survey-App.git

cd project
python manage.py runserver
And navigate to http://127.0.0.1:8000/



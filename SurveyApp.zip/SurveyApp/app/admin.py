from django.contrib import admin
from .models import Poll, Rate
# Register your models here.
admin.site.register(Poll)
admin.site.register(Rate)
// Rating Initialization
$(document).ready(function() {
  $('#rateMe4').mdbRate();
});